<?php

require __DIR__ . '/vendor/autolad.php';

print_r($GLOBALS);