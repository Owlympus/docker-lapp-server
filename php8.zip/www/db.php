<?php

$db = new PDO('pgsql:host=php8_db;dbname=php8;', 'postgres', 'root');
//$db = new PDO('pgsql:host=localhost;dbname=php8;', 'postgres', 'root');

var_dump($db);